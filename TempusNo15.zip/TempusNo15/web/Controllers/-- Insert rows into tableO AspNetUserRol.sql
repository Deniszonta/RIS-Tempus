-- Insert rows into tableO AspNetUserRoles'
INSERT INTO AspNetUserRoles
( -- columns to insert data into
 UserId, RoleId
)
VALUES
( -- first row: values for the columns in the list above
 '7daa3b41-be0f-44da-8bcd-45f0a5c9d308', 1
),
( -- second row: values for the columns in the list above
 '7daa3b41-be0f-44da-8bcd-45f0a5c9d308', 2
),
( -- second row: values for the columns in the list above
 '7daa3b41-be0f-44da-8bcd-45f0a5c9d308', 3
),
( -- second row: values for the columns in the list above
 'd1bab291-6c57-4cc8-8f3e-083ee521e1b0', 2
)
-- add more rows here
GO